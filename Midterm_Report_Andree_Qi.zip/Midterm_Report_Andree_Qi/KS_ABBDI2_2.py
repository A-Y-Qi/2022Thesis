#input the libraries
from numpy import *
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import axes3d

# Set up grid and two-solution initial data:
N = 256
dt = 0.05
x = 16*(2*pi/N)*arange(-N/2.0,N/2.0)
#initial condition for ux
u = cos(x/16)*(1+sin(x/16))
u_hat = fft.fft(u)
uold = cos((x-dt)/16)*(1+sin((x-dt)/16))
uold_hat = fft.fft(uold)
k = hstack([arange(0,N/2.0),0,arange(-N/2.0+1,0)])*(1/16)

# Solve PDE by and plot results by only AB/BDII
tmax = 100
nplt = floor((tmax/25)/dt)
nmax = int(round(tmax/dt))
udata = [u]
tdata = [0]
a0=3/2*ones(len(k))
a1=-2
a2=1/2
b0=2
b1=-1
g = 1/(a0-(k**2-k**4)*dt)

for n in range(1,nmax+1):
    t = n*dt
    g = -1j*dt*k
    #the fourier transform of u^2
    usq_hat=fft.fft(u**2)
    uoldsq_hat=fft.fft(uold**2)
    a=g*b0*usq_hat/2
    b=g*b1*uoldsq_hat/2
    c=a1*u_hat
    d=a2*uold_hat
    e=1/(a0-dt*(k**2-k**4))
    unew_hat=(a+b-c-d)*e
    uold_hat=u_hat
    u_hat=unew_hat
    u = real(fft.ifft(u_hat))
    uold=real(fft.ifft(uold_hat))
    if ((n%int(nplt))==0):
        udata.append(list(u))
        tdata.append(t)

#plot the figure
fig3 = plt.figure()
X, Y = meshgrid(x, tdata)
ax = axes3d.Axes3D(fig3)


u3=array(udata)


ax.plot_surface(X,Y,u3,rstride=1, cstride=1,cmap='viridis', edgecolor='none')
#ax.set_xlim(-pi, pi)
#ax.set_ylim(0, tmax)
#ax.set_zlim(0, 3)
ax.set_xlabel('x')
ax.set_ylabel('t')
plt.show()