#input the libraries
from numpy import *
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import axes3d

# Set up grid and two-solution initial data:
N = 128
dt = 0.05
x = (2*pi/N)*arange(-N/2.0,N/2.0)
#initial condition for ux
u = exp(-x**2)
v = fft.fft(u)
k = hstack([arange(0,N/2.0),0,arange(-N/2.0+1,0)])
# Solve PDE and plot results:
tmax = 20
nplt = floor((tmax/25)/dt)
nmax = int(round(tmax/dt))
udata = [u]
tdata = [0]
for n in range(1,nmax+1):
    t = n*dt
    g = -1j*dt*k
    E = exp(-dt*(k**4-k**2)) #integrator
    E2 = E**2
    a = g*fft.fft(real(fft.ifft(v))**2)
    b = g*fft.fft(real(fft.ifft(E*(v + a/2.0))**2))          # 4th-order
    c = g* fft.fft(real(fft.ifft(E*v + b/2.0))**2)            # Runge-Kutta
    d = g*fft.fft(real(fft.ifft(E2*v + E*c))**2)
    v = E2*v + (E2*a + 2*E*(b+c) +d)/6.0
    if ((n%int(nplt))==0):
        u = real(fft.ifft(v))
        udata.append(list(u))
        tdata.append(t)
        
fig = plt.figure()
X, Y = meshgrid(x, tdata)
ax = axes3d.Axes3D(fig)



u2=array(udata)
Y2=array(Y[:,1])
X2=array(X[1])

b=broadcast(X,Y)


ax.plot_surface(X,Y,u2,rstride=1, cstride=1,cmap='viridis', edgecolor='none')
#ax.set_xlim(-pi, pi)
#ax.set_ylim(0, tmax)
#ax.set_zlim(0, 2)
ax.set_xlabel('x')
ax.set_ylabel('t')
plt.show()

